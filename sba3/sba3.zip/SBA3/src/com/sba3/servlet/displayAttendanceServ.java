package com.sba3.servlet;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.sba3.dao.StudentDao;
import com.sba3.model.Attendance;

/**
 * Servlet implementation class displayAttendanceServ
 */
@WebServlet("/displayAttendanceServ")
public class displayAttendanceServ extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public displayAttendanceServ() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		int showsem =Integer.parseInt(request.getParameter("showsem"));  
		String showdate=request.getParameter("showdate"); 
		
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		Date selectdate=null;
		try
		{
		selectdate=sdf.parse(showdate);
		}
		catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();
		}
		
		
		StudentDao dao =new StudentDao();
		
	ArrayList<Attendance>displaystatus= dao.displayAttendance(showsem, selectdate);
	
	HttpSession session=request.getSession();
	session.setAttribute("displaystatus",displaystatus);

	RequestDispatcher rd= request.getRequestDispatcher("displayAttendanceForm.jsp");
	rd.forward(request, response);
		
		

		
	}

}
