package com.sba3.model;

import java.util.Date;

public class Attendance {
	
	private int studId;
	private String studName;
	private int sem;
	Date attendanceDate;
	private String attendanceStatus;
	public int getStudId() {
		return studId;
	}
	public void setStudId(int studId) {
		this.studId = studId;
	}
	public String getStudName() {
		return studName;
	}
	public void setStudName(String studName) {
		this.studName = studName;
	}
	public int getSem() {
		return sem;
	}
	public void setSem(int sem) {
		this.sem = sem;
	}
	public Date getAttendanceDate() {
		return attendanceDate;
	}
	public void setAttendanceDate(Date attendanceDate) {
		this.attendanceDate = attendanceDate;
	}
	public String getAttendanceStatus() {
		return attendanceStatus;
	}
	public void setAttendanceStatus(String attendanceStatus) {
		this.attendanceStatus = attendanceStatus;
	}
	public Attendance(int studId, String studName, int sem, Date attendanceDate, String attendanceStatus) {
		super();
		this.studId = studId;
		this.studName = studName;
		this.sem = sem;
		this.attendanceDate = attendanceDate;
		this.attendanceStatus = attendanceStatus;
	}
	@Override
	public String toString() {
		return "Attendance [studId=" + studId + ", studName=" + studName + ", sem=" + sem + ", attendanceDate="
				+ attendanceDate + ", attendanceStatus=" + attendanceStatus + "]";
	}
	
	

}
