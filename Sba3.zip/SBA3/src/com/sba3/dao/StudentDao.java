package com.sba3.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;

import com.sba3.dbutil.DBConnection;
import com.sba3.model.Attendance;
import com.sba3.model.Students;

public class StudentDao {
	
	public ArrayList<Students> displaySem(int sem)
	{
	try
	{
	
	Connection con=DBConnection.getConnect();
	String sql="select * from students where sem=?";
	
	PreparedStatement stat=con.prepareStatement(sql);
	stat.setInt(1,sem);
	ResultSet rs= stat.executeQuery();
	
	ArrayList<Students> studentsem=new ArrayList<>();
	
	while(rs.next())
	{
	int studId=	rs.getInt("studId");
	
	String studName= rs.getString("studName");
	
	int studSem=rs.getInt("sem");
	
	Students students =new Students(studId, studName, studSem);
	
	studentsem.add(students);
	
	}
	
	return studentsem;
	
	}
	catch (Exception e) {
	// TODO: handle exception
	e.printStackTrace();
	}
	return null;
	}
	
	
	public void attendanceInsert(Attendance attendance)
	{
		try
		{
		
		Connection con=DBConnection.getConnect();
		String sql="insert into attendance values(?,?,?,?,?)";
		PreparedStatement stat=con.prepareStatement(sql);
		stat.setInt(1,attendance.getStudId());
		stat.setString(2,attendance.getStudName());
		stat.setInt(3,attendance.getSem());
		
		stat.setDate(4,new java.sql.Date(attendance.getAttendanceDate().getYear(),attendance.getAttendanceDate().getMonth(),attendance.getAttendanceDate().getDate()));
		
		stat.setString(5,"Absent");
		
 stat.executeUpdate();
		
		
		}
		
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			}
		
	}
	
	
	
	public void updateAttendance(String mark)
	{
		try
		{
		
		Connection con=DBConnection.getConnect();
		
		String sql="update attendance set AttendanceStatus=? where studId=?";
		PreparedStatement stat=con.prepareStatement(sql);
		stat.setString(1,"P");
		stat.setString(2,mark);
		stat.executeUpdate();
		
		}
		
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			}
		
		
	}

	
	
	public ArrayList<Attendance> displayAttendance(int studsem, Date selectdate)
	{
		try
		{
		
		Connection con=DBConnection.getConnect();
		
		System.out.println(studsem +    "      "+selectdate);
		
		String sql="select * from attendance where sem=? and AttendanceDate =?";
		
		PreparedStatement stat=con.prepareStatement(sql);
		
		stat.setInt(1,studsem);
		
		
		stat.setDate(2, new java.sql.Date(selectdate.getTime()));        
		
		ResultSet rs= stat.executeQuery();  
		
		ArrayList<Attendance> showlist=new ArrayList<>();
		
		while(rs.next())
		{
		int stuid=	rs.getInt("studId");
		
		String studName= rs.getString("studName");
		
		int studSem=rs.getInt("sem");
		
		Date attenddate=rs.getDate("AttendanceDate");
		
		String studstatus= rs.getString("AttendanceStatus");
		
		Attendance attendance= new Attendance(stuid, studName, studSem, attenddate,studstatus); 
		
		showlist.add(attendance);
		
		}
		return showlist;
		}
		
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			}
		return null;
		
	}
		
		

}



