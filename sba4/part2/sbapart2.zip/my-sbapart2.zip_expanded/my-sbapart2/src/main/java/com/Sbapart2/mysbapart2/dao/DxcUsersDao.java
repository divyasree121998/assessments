package com.Sbapart2.mysbapart2.dao;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.Sbapart2.mysbapart2.model.DxcUsers;


@Component
@Transactional
public class DxcUsersDao {
	 @Autowired
		SessionFactory sessionFactor;
	    public String saveUser(DxcUsers dxcUsers) {
	    	try {
	    	Session session=sessionFactor.getCurrentSession();
	    	session.save(dxcUsers);
	    	return "user created";
	    	}
	    	catch (Exception e) {
				// TODO: handle exception
	    		e.printStackTrace();
			}
	    	return "cannot create user";
	    }
	    
	    public List<DxcUsers> getAllUsers()
		{
		try
		{
			Session session=sessionFactor.getCurrentSession();
			Query query=session.createQuery("select a from DxcUsers a");
		    System.out.println(query);
		ArrayList<DxcUsers> dxcusers=(ArrayList<DxcUsers>)query.list();
		return dxcusers ;
		}
		catch (Exception e) {
		e.printStackTrace();
		}
		return null;
		}
	    
		public DxcUsers getUserById(int userId){
			try{
				Session session=sessionFactor.getCurrentSession();
			DxcUsers dxcUsers=(DxcUsers)session.get(DxcUsers.class,userId);
			return dxcUsers;
			}
			catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			}
			return null;
			}
		public String updateUserById(DxcUsers dxcUsers){
			try{
			Session session=sessionFactor.getCurrentSession();
			System.out.println("dxcUsers"+dxcUsers);
			session.update("DxcUsers",dxcUsers);
			return "Password Updated";
			}
			catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			}
			return "Cannot Update Password";
			}
		
	    
}
